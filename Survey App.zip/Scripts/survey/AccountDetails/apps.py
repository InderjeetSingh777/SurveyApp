from django.apps import AppConfig


class AccountdetailsConfig(AppConfig):
    name = 'AccountDetails'
